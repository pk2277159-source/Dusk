# Dusk Launcher (native Android, no HTML)
1. Android Studio > Open > is folder ko select karo, Gradle sync hone do.
2. Phone par USB debugging on karke Run dabao (ya Build > Build APK).
3. Settings > Apps > Default apps > Home app > Dusk Launcher.
4. Upar se neeche swipe karke "Allow notification access" tap karo.
Gestures: neeche se upar = app drawer, upar se neeche = control centre + notifications.
Lock: control centre mein "Lock phone", fingerprint sensor ko hold karo.
