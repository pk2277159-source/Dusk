package com.dusk.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    companion object {
        var inst: NotifService? = null
        var onChange: (() -> Unit)? = null

        fun list(): List<StatusBarNotification> = try {
            inst?.activeNotifications?.filter {
                val e = it.notification.extras
                (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 &&
                    (e.getCharSequence(Notification.EXTRA_TITLE) != null || e.getCharSequence(Notification.EXTRA_TEXT) != null)
            }?.sortedByDescending { it.postTime } ?: emptyList()
        } catch (e: Exception) { emptyList() }

        fun open(n: StatusBarNotification) {
            try { n.notification.contentIntent?.send() } catch (e: Exception) {}
            if ((n.notification.flags and Notification.FLAG_AUTO_CANCEL) != 0) dismiss(n.key)
        }
        fun dismiss(k: String) { try { inst?.cancelNotification(k) } catch (e: Exception) {} }
        fun clearAll() { try { inst?.cancelAllNotifications() } catch (e: Exception) {} }
    }
    override fun onListenerConnected() { inst = this; onChange?.invoke() }
    override fun onListenerDisconnected() { inst = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { onChange?.invoke() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { onChange?.invoke() }
}
