package com.dusk.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityManager
import android.app.Notification
import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.math.abs

class MainActivity : Activity() {
    data class App(val label: String, val pkg: String, val icon: Drawable)

    private val W = Color.WHITE
    private val DIM = 0xB3FFFFFF.toInt()
    private val AC = 0xFFFF8A5C.toInt()
    private val TEAL = 0xFF2FD3C0.toInt()
    private var den = 1f
    private fun dp(x: Int) = (x * den).toInt()
    private val sh: Float get() = resources.displayMetrics.heightPixels.toFloat()

    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var pages: HorizontalScrollView
    private lateinit var grid: GridLayout
    private lateinit var dockBar: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var appGrid: GridView
    private lateinit var shade: ScrollView
    private lateinit var notifBox: LinearLayout
    private lateinit var lock: FrameLayout
    private lateinit var lockBox: LinearLayout
    private lateinit var iconBar: LinearLayout
    private lateinit var batTxt: TextView
    private lateinit var hint: TextView
    private lateinit var fp: FP
    private lateinit var rBat: Ring
    private lateinit var rSto: Ring
    private lateinit var rRam: Ring
    private var state = 1
    private var apps = listOf<App>()
    private var shown = listOf<App>()
    private var x0 = 0f
    private var y0 = 0f
    private var torchOn = false
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { stats(); drawNotifs(); h.postDelayed(this, 30000) } }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View = cell(shown[i])
    }

    // ---------- custom views ----------
    inner class Wall(c: Context) : View(c) {
        private val p = Paint()
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat(); val hh = height.toFloat()
            p.shader = LinearGradient(0f, 0f, w * .3f, hh, 0xFF0B2233.toInt(), 0xFF1A2236.toInt(), Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, hh, p)
            fun blob(x: Float, y: Float, r: Float, c: Int) {
                p.shader = RadialGradient(x, y, r, c, c and 0xFFFFFF, Shader.TileMode.CLAMP); cv.drawCircle(x, y, r, p)
            }
            blob(w * .2f, hh * .12f, w * .85f, 0xAA2FD3C0.toInt())
            blob(w * .95f, hh * .4f, w * .8f, 0xCCFF8A5C.toInt())
            blob(w * .3f, hh * .98f, w * .9f, 0xBBFFC46B.toInt())
            blob(w * .85f, hh, w * .7f, 0x887A5CFF.toInt())
        }
    }

    inner class Ring(c: Context, private val col: Int) : View(c) {
        private var v = 0
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = dp(6).toFloat() }
        private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = W; textAlign = Paint.Align.CENTER; textSize = dp(13).toFloat() }
        fun set(x: Int) { v = x; invalidate() }
        override fun onDraw(cv: Canvas) {
            val m = dp(6).toFloat(); val r = RectF(m, m, width - m, height - m)
            p.color = 0x33FFFFFF; cv.drawArc(r, 0f, 360f, false, p)
            p.color = col; cv.drawArc(r, -90f, 360f * v / 100, false, p)
            cv.drawText("$v%", width / 2f, height / 2f - (t.descent() + t.ascent()) / 2, t)
        }
    }

    inner class FP(c: Context) : View(c) {
        var p = 0f
        var ok = false
        var onOk: () -> Unit = {}
        private var anim: ValueAnimator? = null
        private val a = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
        override fun onDraw(cv: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val r = width / 2f - dp(6)
            a.style = Paint.Style.FILL; a.color = 0x26FFFFFF; cv.drawCircle(cx, cy, r, a)
            a.style = Paint.Style.STROKE; a.strokeWidth = dp(2).toFloat(); a.color = if (ok) TEAL else W
            for (i in 1..5) { val rr = r * i / 6.2f; cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, 195f + i * 7, 230f - i * 8, false, a) }
            cv.drawLine(cx, cy - r * .12f, cx, cy + r * .45f, a)
            if (p > 0f && !ok) {
                a.color = 0x992FD3C0.toInt(); val y = cy - r + 2 * r * ((p * 3) % 1f); cv.drawLine(cx - r * .8f, y, cx + r * .8f, y, a)
                a.color = TEAL; a.strokeWidth = dp(3).toFloat(); val o = r + dp(5)
                cv.drawArc(cx - o, cy - o, cx + o, cy + o, -90f, 360f * p, false, a)
            }
        }
        fun shake() {
            val s = dp(8).toFloat()
            animate().translationX(-s).setDuration(60).withEndAction { animate().translationX(s).setDuration(60).withEndAction { animate().translationX(0f).setDuration(60) } }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (ok) return true
                    anim?.cancel()
                    anim = ValueAnimator.ofFloat(0f, 1f).apply {
                        duration = 700
                        addUpdateListener { p = it.animatedValue as Float; invalidate() }
                        addListener(object : AnimatorListenerAdapter() {
                            override fun onAnimationEnd(an: Animator) {
                                if (p >= 1f) {
                                    ok = true; hint.text = "Unlocked"; performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); invalidate()
                                    postDelayed({ onOk(); ok = false; p = 0f; hint.text = "Touch the sensor to unlock"; invalidate() }, 300)
                                }
                            }
                        })
                        start()
                    }
                    animate().scaleX(1.08f).scaleY(1.08f).setDuration(150)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    animate().scaleX(1f).scaleY(1f).setDuration(150)
                    if (!ok) { anim?.cancel(); if (p > .03f) { shake(); hint.text = "Hold a little longer" }; p = 0f; invalidate() }
                }
            }
            return true
        }
    }

    // ---------- helpers ----------
    private fun glass(r: Int, fill: Int = 0x24FFFFFF) = GradientDrawable().apply { setColor(fill); cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
    private fun tv(t: String, sp: Float, c: Int = W, light: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (light) typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
    private fun clock(f: String, sp: Float, light: Boolean = false) = TextClock(this).apply {
        format12Hour = f; format24Hour = f; textSize = sp; setTextColor(W); if (light) typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    }
    private fun LinearLayout.add(v: View, top: Int = 12) = addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    private fun GridLayout.put(v: View) = addView(v, GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)).apply { width = 0; setMargins(dp(4), dp(4), dp(4), dp(4)) })
    private fun btn(t: String, f: () -> Unit) = tv(t, 15f).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(14), dp(20), dp(14)); background = glass(26); setOnClickListener { f() } }
    private fun watcher(f: (String) -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { f(s.toString()) }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    }
    private fun round(v: View, r: Int) { v.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(x: View, o: Outline) { o.setRoundRect(0, 0, x.width, x.height, dp(r).toFloat()) } }; v.clipToOutline = true }
    private fun iconOf(p: String): Drawable = try { packageManager.getApplicationIcon(p) } catch (e: Exception) { ColorDrawable(0x33FFFFFF) }
    private fun appName(p: String) = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }

    private fun cell(a: App, label: Boolean = true): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6))
        addView(ImageView(context).apply { setImageDrawable(a.icon); round(this, 16) }, LinearLayout.LayoutParams(dp(56), dp(56)))
        if (label) addView(tv(a.label, 11f).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(72), -2).apply { topMargin = dp(5) })
        setOnClickListener { packageManager.getLaunchIntentForPackage(a.pkg)?.let { startActivity(it) } }
    }

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        den = resources.displayMetrics.density
        window.navigationBarColor = 0xFF05080D.toInt()
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        if (Build.VERSION.SDK_INT >= 28) { val lp = window.attributes; lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES; window.attributes = lp }
        root = FrameLayout(this)
        root.addView(Wall(this), FrameLayout.LayoutParams(-1, -1))
        buildHome(); buildDrawer(); buildShade(); buildLock(); buildStatus()
        setContentView(root)
        loadApps(); go(1, 0)
        NotifService.onChange = { runOnUiThread { drawNotifs() } }
        val f = IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package") }
        registerReceiver(object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { loadApps() } }, f)
    }
    override fun onResume() { super.onResume(); h.removeCallbacks(tick); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); go(1); pages.smoothScrollTo(0, 0) }
    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (state == 2 || state == 3) go(1) else pages.smoothScrollTo(0, 0) }

    // ---------- gestures + state ----------
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) { x0 = e.rawX; y0 = e.rawY }
        if (e.action == MotionEvent.ACTION_UP) {
            val dx = e.rawX - x0; val dy = e.rawY - y0
            if (abs(dy) > dp(80) && abs(dy) > abs(dx) * 1.5f) when {
                state == 1 && dy < 0 && y0 > dp(260) -> go(2)
                state == 1 && dy > 0 && y0 < dp(130) -> go(3)
                state == 2 && dy > 0 && (y0 < dp(120) || !appGrid.canScrollVertically(-1)) -> go(1)
                state == 3 && dy < 0 && shade.scrollY < 5 -> go(1)
                state == 0 && dy < 0 -> { fp.shake(); hint.text = "Use the fingerprint sensor" }
            }
        }
        return super.dispatchTouchEvent(e)
    }
    private fun go(s: Int, dur: Long = 420) {
        state = s
        lock.animate().translationY(if (s == 0) 0f else -sh).setDuration(dur).start()
        drawer.animate().translationY(if (s == 2) 0f else sh).setDuration(dur).start()
        shade.animate().translationY(if (s == 3) 0f else -sh).setDuration(dur).start()
        val back = s == 2 || s == 3
        home.animate().scaleX(if (back) .92f else 1f).scaleY(if (back) .92f else 1f).alpha(if (back) .5f else 1f).setDuration(dur).start()
        if (s != 2) (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(root.windowToken, 0)
    }

    // ---------- apps ----------
    private fun loadApps() {
        val pm = packageManager
        apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        val dk = mutableListOf<App>()
        listOf("phone|dial", "messag|sms", "chrome|browser|firefox|brave", "camera").forEach { r ->
            val re = Regex(r, RegexOption.IGNORE_CASE)
            apps.firstOrNull { re.containsMatchIn(it.label + it.pkg) && it !in dk }?.let { dk.add(it) }
        }
        apps.forEach { if (dk.size < 4 && it !in dk) dk.add(it) }
        grid.removeAllViews(); dockBar.removeAllViews()
        apps.filter { it !in dk }.take(8).forEach { grid.put(cell(it)) }
        dk.forEach { dockBar.addView(cell(it, false), LinearLayout.LayoutParams(0, -2, 1f)) }
        filterApps("")
    }
    private fun filterApps(q: String) { shown = apps.filter { it.label.contains(q, true) }; adapter.notifyDataSetChanged() }

    // ---------- home ----------
    private fun buildHome() {
        val pw = resources.displayMetrics.widthPixels
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pages = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val strip = LinearLayout(this); pages.addView(strip)
        fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(64), dp(16), 0) }.also { strip.addView(it, LinearLayout.LayoutParams(pw, -1)) }
        val p1 = page(); val p2 = page()
        p1.add(clock("EEE, d MMM", 40f, true), 0)
        p1.add(tv("Haze, 29°  (demo weather)", 15f, DIM), 2)
        val row = LinearLayout(this)
        val wx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = glass(28) }
        wx.addView(tv("Mumbai", 13f, DIM)); wx.addView(tv("29°", 38f, W, true)); wx.addView(tv("🌤️", 30f)); wx.addView(tv("H 31°  L 25°", 13f, DIM))
        val cal = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = glass(28) }
        cal.addView(clock("MMMM", 13f).apply { setTextColor(AC) }); cal.addView(clock("d", 44f, true)); cal.addView(tv("Today", 14f, DIM))
        row.addView(wx, LinearLayout.LayoutParams(0, dp(160), 1f).apply { marginEnd = dp(6) })
        row.addView(cal, LinearLayout.LayoutParams(0, dp(160), 1f).apply { marginStart = dp(6) })
        p1.add(row, 14)
        grid = GridLayout(this).apply { columnCount = 4 }
        p1.add(grid, 14)
        // page 2: widgets
        val mus = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = glass(28) }
        mus.addView(tv("🎧", 28f).apply { gravity = Gravity.CENTER; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(AC, 0xFF7A5CFF.toInt())).apply { cornerRadius = dp(18).toFloat() } }, LinearLayout.LayoutParams(dp(64), dp(64)))
        val mt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mt.addView(tv("Midnight Drive", 16f)); mt.addView(tv("Neon Tides", 13f, DIM))
        mus.addView(mt, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        var playing = true
        mus.addView(tv("⏸", 26f).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { playing = !playing; text = if (playing) "⏸" else "▶️" } })
        p2.add(mus, 0)
        val rings = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(16), dp(8), dp(16)); background = glass(28) }
        rBat = Ring(this, TEAL); rSto = Ring(this, 0xFFFFC46B.toInt()); rRam = Ring(this, AC)
        listOf(rBat to "Battery", rSto to "Storage", rRam to "RAM").forEach { (r, n) ->
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            c.addView(r, LinearLayout.LayoutParams(dp(68), dp(68))); c.addView(tv(n, 12f, DIM))
            rings.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        }
        p2.add(rings, 14)
        val sp = getSharedPreferences("dusk", MODE_PRIVATE)
        val note = EditText(this).apply { setText(sp.getString("note", "")); hint = "Quick note..."; setTextColor(W); setHintTextColor(DIM); textSize = 14f; gravity = Gravity.TOP; background = glass(28); setPadding(dp(16), dp(14), dp(16), dp(14)); addTextChangedListener(watcher { sp.edit().putString("note", it).apply() }) }
        p2.addView(note, LinearLayout.LayoutParams(-1, dp(150)).apply { topMargin = dp(14) })
        home.addView(pages, LinearLayout.LayoutParams(-1, 0, 1f))
        val dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val dv = List(2) { View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(W) } } }
        dv.forEach { dots.addView(it, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) }) }
        fun mark(i: Int) { dv[0].alpha = if (i == 0) 1f else .4f; dv[1].alpha = if (i == 1) 1f else .4f }
        mark(0)
        pages.setOnScrollChangeListener { _, x, _, _, _ -> mark(if (x > pw / 2) 1 else 0) }
        pages.setOnTouchListener { v, e -> if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.postDelayed({ pages.smoothScrollTo(if (pages.scrollX > pw / 2) pw else 0, 0) }, 60); false }
        home.addView(dots, LinearLayout.LayoutParams(-1, dp(20)))
        home.addView(tv("🔍   Search apps", 15f, DIM).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), 0, dp(20), 0); background = glass(26); setOnClickListener { go(2) } },
            LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(dp(16), dp(6), dp(16), dp(10)) })
        dockBar = LinearLayout(this).apply { setPadding(dp(10), dp(12), dp(10), dp(12)); background = glass(32) }
        home.addView(dockBar, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), 0, dp(12), dp(16)) })
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- drawer ----------
    private fun buildDrawer() {
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(46), dp(12), 0)
            background = GradientDrawable().apply { setColor(0xE60A141E.toInt()); val r = dp(32).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        val q = EditText(this).apply { hint = "Search apps"; setHintTextColor(DIM); setTextColor(W); textSize = 15f; setSingleLine(); background = glass(24); setPadding(dp(20), 0, dp(20), 0); addTextChangedListener(watcher { filterApps(it) }) }
        drawer.addView(q, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(dp(4), 0, dp(4), dp(10)) })
        appGrid = GridView(this).apply { numColumns = 4; verticalSpacing = dp(14); selector = ColorDrawable(0); this.adapter = this@MainActivity.adapter; clipToPadding = false; setPadding(0, dp(8), 0, dp(24)) }
        drawer.addView(appGrid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- control centre + notification shade ----------
    private fun tile(e: String, n: String, on: Boolean, act: (Boolean) -> Unit): View = tv("$e  $n", 14f).apply {
        gravity = Gravity.CENTER; setPadding(dp(8), dp(16), dp(8), dp(16)); var s = on
        fun paint() {
            background = if (s) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(AC, 0xFFFFB067.toInt())).apply { cornerRadius = dp(26).toFloat() } else glass(26)
            setTextColor(if (s) 0xFF2A1206.toInt() else W)
        }
        paint(); setOnClickListener { s = !s; paint(); act(s) }
    }
    private fun seek(icon: String, max: Int, cur: Int, f: (Int) -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)); background = glass(28)
        addView(tv(icon, 20f))
        addView(SeekBar(context).apply {
            this.max = max; progress = cur; progressTintList = ColorStateList.valueOf(W); thumbTintList = ColorStateList.valueOf(W)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(10) })
    }
    private fun open(a: String) = startActivity(Intent(a))

    private fun buildShade() {
        shade = ScrollView(this).apply { setBackgroundColor(0xE608101A.toInt()); isVerticalScrollBarEnabled = false }
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(56), dp(16), dp(80)) }
        shade.addView(c)
        c.add(clock("h:mm", 36f, true), 0)
        c.add(clock("EEEE, d MMMM", 14f).apply { setTextColor(DIM) }, 0)
        val g = GridLayout(this).apply { columnCount = 2 }
        g.put(tile("📶", "Wi-Fi", true) { open(Settings.ACTION_WIFI_SETTINGS) })
        g.put(tile("🔵", "Bluetooth", true) { open(Settings.ACTION_BLUETOOTH_SETTINGS) })
        g.put(tile("✈️", "Airplane", false) { open(Settings.ACTION_AIRPLANE_MODE_SETTINGS) })
        g.put(tile("🔦", "Torch", false) { on ->
            try { val m = getSystemService(CAMERA_SERVICE) as CameraManager; m.setTorchMode(m.cameraIdList[0], on) } catch (e: Exception) {}
        })
        g.put(tile("📍", "Location", true) { open(Settings.ACTION_LOCATION_SOURCE_SETTINGS) })
        g.put(tile("☀️", "Display", false) { open(Settings.ACTION_DISPLAY_SETTINGS) })
        c.add(g, 14)
        c.add(seek("☀️", 100, 60) { p -> val lp = window.attributes; lp.screenBrightness = maxOf(p, 5) / 100f; window.attributes = lp }, 12)
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        c.add(seek("🔊", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) { p -> am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) }, 10)
        val hd = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0) }
        hd.addView(tv("Notifications", 16f), LinearLayout.LayoutParams(0, -2, 1f))
        hd.addView(tv("Clear all", 13f, DIM).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { NotifService.clearAll() } })
        c.add(hd, 18)
        notifBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.add(notifBox, 6)
        c.add(btn("🔒  Lock phone") { go(0) }, 20)
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- lock screen ----------
    private fun buildLock() {
        lock = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), dp(84), dp(16), 0) }
        col.add(clock("EEEE, d MMMM", 17f).apply { setTextColor(DIM); gravity = Gravity.CENTER }, 0)
        col.add(clock("h:mm", 92f, true).apply { gravity = Gravity.CENTER; includeFontPadding = false }, 0)
        lockBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.add(lockBox, 24)
        lock.addView(col, FrameLayout.LayoutParams(-1, -1))
        hint = tv("Touch the sensor to unlock", 13f, DIM)
        fp = FP(this).apply { onOk = { go(1) } }
        val bot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bot.addView(fp, LinearLayout.LayoutParams(dp(84), dp(84)))
        bot.addView(hint, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        lock.addView(bot, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(36) })
        root.addView(lock, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- status bar + notifications ----------
    private fun buildStatus() {
        val s = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(24), dp(10), dp(24), 0) }
        s.addView(clock("h:mm", 14f))
        iconBar = LinearLayout(this); s.addView(iconBar, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        s.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        batTxt = tv("🔋", 12f); s.addView(batTxt)
        s.setOnClickListener { if (state == 1) go(3) }
        root.addView(s, FrameLayout.LayoutParams(-1, dp(44)))
    }
    private fun hasAccess() = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    private fun card(n: StatusBarNotification): View {
        val e = n.notification.extras
        val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val x = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(6), dp(12)); background = glass(22) }
        row.addView(ImageView(this).apply { setImageDrawable(iconOf(n.packageName)); round(this, 11) }, LinearLayout.LayoutParams(dp(36), dp(36)))
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(tv(t.ifEmpty { appName(n.packageName) }, 14f).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; typeface = Typeface.DEFAULT_BOLD })
        c.addView(tv(x, 13f, DIM).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        row.addView(tv("✕", 16f, DIM).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { NotifService.dismiss(n.key) } })
        row.setOnClickListener { NotifService.open(n); go(1) }
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        return row
    }
    private fun drawNotifs() {
        val list = NotifService.list()
        notifBox.removeAllViews(); lockBox.removeAllViews(); iconBar.removeAllViews()
        if (list.isEmpty()) notifBox.addView(
            if (!hasAccess()) btn("Allow notification access") { open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
            else tv("No new notifications", 14f, DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20)) })
        list.forEach { notifBox.addView(card(it)) }
        list.take(2).forEach { lockBox.addView(card(it)) }
        list.take(4).forEach { iconBar.addView(ImageView(this).apply { setImageDrawable(iconOf(it.packageName)) }, LinearLayout.LayoutParams(dp(15), dp(15)).apply { marginStart = dp(5) }) }
    }
    private fun stats() {
        val bat = (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        batTxt.text = "🔋 $bat%"; rBat.set(bat)
        val sf = StatFs(Environment.getDataDirectory().path)
        rSto.set((100 - sf.availableBytes * 100 / sf.totalBytes).toInt())
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        rRam.set((100 - mi.availMem * 100 / mi.totalMem).toInt())
    }
}
